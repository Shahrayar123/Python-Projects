# AI_Attendence_App_In_Python
A program to detect faces of people and mark the attendence that will be recorded in the <br>
in the csv file
